## R_資料科學程式設計

- [課程大綱](https://nol.ntu.edu.tw/nol/coursesearch/print_table.php?course_id=H03%2004010&class=&dpt_code=H020&ser_no=46352&semester=106-2&lang=CH)

- [資料科學程式設計GitBook](https://www.gitbook.com/book/pecu/r_)
- [資料科學程式設計GitHub](https://github.com/NTU-CSX-DataScience/106-2RSampleCode)


| Date   | W    | Link                                                           |
| --:    | --   | --                                                             |
| 03/01  |  1   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_1 |
| 03/08  |  2   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_2 |
| 03/15  |  3   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_3 |
| 03/29  |  5   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_5 |
| 04/05  |  6   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_6 |
| 04/12  |  7   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_7 |
| 04/19  |  8   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_8 |
| 04/26  |  9   | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_9 |
| 05/03  |  10  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_10 |
| 05/10  |  11  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_11 |
| 05/17  |  12  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_12 |
| 05/24  |  13  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_13 |
| 05/31  |  14  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_14 |
| 06/07  |  15  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_15 |
| 06/14  |  16  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_16 |
| 06/21  |  17  | https://github.com/NTU-CSX-DataScience/106-2RSampleCode/tree/master/week_17 |